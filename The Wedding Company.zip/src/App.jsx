import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Login from './pages/Login'
import Tasks from './pages/Tasks'
import { AuthProvider, useAuth } from './lib/auth'

function Nav() {
  const { user, logout } = useAuth();
  return (
    <nav className="bg-slate-800 text-white p-4 flex justify-between">
      <div className="flex items-center gap-4">
        <Link to="/" className="font-bold">Company Frontend Assignment</Link>
        {user && <Link to="/tasks" className="opacity-90">Tasks</Link>}
      </div>
      <div>
        {user ? (
          <button onClick={logout} className="bg-slate-700 px-3 py-1 rounded">Logout</button>
        ) : (
          <Link to="/login" className="bg-slate-600 px-3 py-1 rounded">Login</Link>
        )}
      </div>
    </nav>
  )
}

export default function App(){
  return (
    <AuthProvider>
      <Nav />
      <main className="p-4 max-w-4xl mx-auto">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/tasks" element={<Tasks/>} />
        </Routes>
      </main>
    </AuthProvider>
  )
}
