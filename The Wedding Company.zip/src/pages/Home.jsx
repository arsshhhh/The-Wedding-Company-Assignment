import React from 'react'
export default function Home(){
  return (
    <section className="space-y-4">
      <h1 className="text-3xl font-bold">Frontend Developer Assignment</h1>
      <p className="text-slate-600">This demo shows a clean, responsive UI with authentication and CRUD for tasks. It uses a small API wrapper that falls back to a mock when no backend is present.</p>
      <div className="bg-white p-4 rounded shadow">
        <h2 className="font-semibold">What to check</h2>
        <ul className="list-disc ml-5">
          <li>Login flow (mocked)</li>
          <li>Tasks list, create, edit, delete</li>
          <li>Responsive layout and accessible controls</li>
        </ul>
      </div>
    </section>
  )
}
