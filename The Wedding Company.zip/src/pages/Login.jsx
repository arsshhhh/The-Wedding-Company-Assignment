import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../lib/auth'

export default function Login(){
  const [email, setEmail] = useState('demo@example.com')
  const [password, setPassword] = useState('pass')
  const [err, setErr] = useState('')
  const { login } = useAuth()
  const nav = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    setErr('')
    try {
      await login(email, password)
      nav('/tasks')
    } catch (e) {
      setErr(e.message || 'Login failed')
    }
  }

  return (
    <div className="max-w-md mx-auto bg-white p-6 rounded shadow">
      <h2 className="text-2xl font-semibold mb-4">Login</h2>
      <form onSubmit={submit} className="space-y-3">
        <div>
          <label className="block text-sm">Email</label>
          <input value={email} onChange={e=>setEmail(e.target.value)} className="w-full border p-2 rounded"/>
        </div>
        <div>
          <label className="block text-sm">Password</label>
          <input type="password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full border p-2 rounded"/>
        </div>
        {err && <div className="text-red-600">{err}</div>}
        <div className="flex justify-end">
          <button className="bg-slate-800 text-white px-4 py-2 rounded">Login</button>
        </div>
      </form>
      <p className="text-sm mt-3 text-slate-600">Use <strong>demo@example.com / pass</strong> (mock)</p>
    </div>
  )
}
