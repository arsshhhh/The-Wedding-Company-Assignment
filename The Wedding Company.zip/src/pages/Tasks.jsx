import React, { useEffect, useState } from 'react'
import { useAuth } from '../lib/auth'
import api from '../lib/api'

export default function Tasks(){
  const { user } = useAuth()
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [title, setTitle] = useState('')
  const [desc, setDesc] = useState('')
  const [editing, setEditing] = useState(null)
  const token = 'mock-token' // when integrating with real backend replace with real JWT

  useEffect(()=>{ load() },[])

  async function load(){
    setLoading(true)
    const data = await api.fetchTasks(token)
    setTasks(data)
    setLoading(false)
  }

  async function add(e){
    e.preventDefault()
    if (!title) return
    const t = await api.createTask(token, { title, description: desc })
    setTasks(prev=>[...prev, t])
    setTitle(''); setDesc('')
  }

  async function toggle(task){
    const updated = await api.updateTask(token, task.id, { completed: !task.completed })
    setTasks(prev=>prev.map(p=> p.id===task.id ? updated : p))
  }

  async function remove(id){
    await api.deleteTask(token, id)
    setTasks(prev=>prev.filter(p=>p.id!==id))
  }

  if (!user) return <div className="text-center p-6">Please login to view tasks.</div>

  return (
    <div className="bg-white p-4 rounded shadow">
      <h2 className="text-xl font-semibold mb-3">Tasks for {user.name}</h2>
      <form onSubmit={add} className="flex gap-2 mb-4">
        <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title" className="flex-1 border p-2 rounded"/>
        <button className="bg-slate-800 text-white px-3 rounded">Add</button>
      </form>

      {loading ? <div>Loading...</div> : (
        <ul className="space-y-2">
          {tasks.map(t=>(
            <li key={t.id} className="flex items-center justify-between border p-2 rounded">
              <div className="flex items-center gap-3">
                <input type="checkbox" checked={t.completed} onChange={()=>toggle(t)} />
                <div>
                  <div className={t.completed ? 'line-through' : ''}>{t.title}</div>
                  <div className="text-sm text-slate-600">{t.description}</div>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={()=>remove(t.id)} className="text-red-600">Delete</button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
